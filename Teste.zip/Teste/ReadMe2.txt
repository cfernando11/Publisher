Olá desenvolvedor,

A segunda fase do teste consiste em escolher um desafio apresentado abaixo e apresenta-lo em detalhes na entrevista com a TMF.

A considerar:
* Obrigatoriamente escolha um desafio de desenvolvimento
* Se quiser optar por fazer mais de um desafio, é permitido.
* A parte mais importante da avaliação será a apresentação da solução desenvolvida, prepare-se para fornecer todos os detalhes e motivos na escolha da construção da solução escolhida no dia da entrevista.

Desafio 1:
* Desenvolver uma aplicação em MVC 5 ou superior(Net Core) com uma tela de crud que se comunica com uma API Net Core com autenticação JWT
 >> Pontuação = 5000 pontos


Desafio 2:
* Desenvolver uma API Net Core com autenticação JWT que executa ações de leitura, gravação e atualização em um banco de dados
* Criar metodos com verbos http post e get
* Criar uma solução que contenha injeção de dependencia e inversão de controle
 >> Pontuação = 2000 pontos


Desafio 3:
* Desenvolver uma API Net Core com autenticação JWT com uma camada de mensageria(Rabbitmq ou Apache Kafka) que executa ações no banco de dados de leitura, gravação e atualização em um banco de dados
* Criar metodos com verbos http post e get
* Criar uma solução que contenha injeção de dependencia e inversão de controle
* Apresentar a solução em operação com as filas, mensageria, conceitos e execução dos envelopes na API Net Core
 >> Pontuação = 7000 pontos

Para soluções em Net Core >> utilizar a versão Net Core 7.0 ou superior
Para soluções em Net Framework >>utilizar a versão 4.7 ou superior
Para soluções em rabbitmq e Apache Kafka >> utulizar a versão que assim desejar.