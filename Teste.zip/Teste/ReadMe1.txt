1º Extrair o Zip "DesafioCandidato.zip" 

2º Execute o arquivo Master.exe e insira a senha @#$%TMFBrasil&2022 que será solicitada

3º Após a extração final dos arquivos, voce encontrará uma solução API em Net Core, o objetivo deste teste é executar uma chamada post desta API.


4° Clique na solution e de um play no projeto, com o postman ou insomnia aberto, faça uma chamada post com a URL "http://localhost/TMF.Publisher/api/v1/Publish/Publish"(Não há necessidade da autenticação previa de JWT) 
passando o seguinte request na chamada post:

{
 "exchange": "string",
 "routingKey": "string",
 "userNameRMQ": "string",
 "passwordRMQ": "string",
 "vHost": "string",
 "hostName": "string",
 "port": 0,
 "data": {},
 "transactionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6"
}

O retorno esperado deve ser obrigatoriamente com este formato:

{

 "transactionId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
 "success": true,
 "isException": true,
 "startTime": "2022-11-10T13:04:38.300Z",
 "endTime": "2022-11-10T13:04:38.300Z",
 "businessErrors": [
   "string"
 ],
 "exceptionErrors": [
   "string"
 ]
}


5º Você perceberá que a API possui alguns erros quando o post é executado, corrija-os para que ela retorne o response no formato mencionado acima. 


6º Após a correção, quando você finalizar e a estrutura estiver ok, encaminhe a API zipada e corrigida por favor.


